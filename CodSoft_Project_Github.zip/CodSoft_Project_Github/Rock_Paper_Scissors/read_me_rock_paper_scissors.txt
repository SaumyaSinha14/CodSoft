TASK -

User Input: Prompt the user to choose rock, paper, or scissors.
Computer Selection: Generate a random choice (rock, paper, or scissors) for
the computer.
Game Logic: Determine the winner based on the user's choice and the
computer's choice.
Rock beats scissors, scissors beat paper, and paper beats rock.
Display Result: Show the user's choice and the computer's choice.
Display the result, whether the user wins, loses, or it's a tie.
Score Tracking (Optional): Keep track of the user's and computer's scores for
multiple rounds.
Play Again: Ask the user if they want to play another round.
User Interface: Design a user-friendly interface with clear instructions and
feedback.


SOLUTION/APPROACH - 

User Input (user_choice function):
The user can select either "rock", "paper", or "scissors".
if any other input is provided then the program will show invalid input.

Computer’s Random Choice (comp_choice function):
The computer randomly selects between "rock", "paper", and "scissors" using the random.choice() function.

Determine the Winner (winner function):
The winner is determined based on the rules:
Rock beats scissors.
Scissors beat paper.
Paper beats rock.
The function returns a message indicating whether the user won, lost, or tied.
